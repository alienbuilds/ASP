﻿using Answer;

internal class Program
{
    static void Main(string[] args)
    {
        //p1 obj1 = new p1();
        //obj1.SwapNumbers();

        //p2 obj2 = new p2();
        //obj2.ConvertKms();

        //p3 obj3= new p3();
        //obj3.Arithmatic();

        //p4 obj4= new p4();
        //obj4.LargestSmalletEvenOdd();

        //p5 obj5= new p5();
        //obj5.ReverseNumber();

        //p6 obj6= new p6();
        //obj6.CheckNumber();

        //p7 obj7= new p7();
        //obj7.LeapYear();

        //p8 obj8= new p8();
        //obj8.Sum();

        //p9 obj9= new p9();
        //obj9.Fibonacci();

        //p10 obj10= new p10();
        //obj10.ArrayOfFloats();

        //p11 obj11= new p11();
        //obj11.SmallLestLargestInFloatArray();

        //p12 obj12= new p12();
        //obj12. SumAndAvgOfArray();

        //p13 obj13= new p13();
        //obj13.ReverseNumber();

        //p14 obj14= new p14();
        //obj14.ReverseNumber();

        p15 obj15= new p15();
        obj15.Palindrome();

    }
}