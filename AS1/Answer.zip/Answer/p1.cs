﻿using System;

namespace Answer
{
    internal class p1
    {
        public void SwapNumbers()
        {
            int a, b;

            Console.WriteLine("Enter value for a: ");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value for b: ");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nSwapping without using a third variable...");
            Console.WriteLine($"BEFORE Swap: a = {a}, b = {b}");
            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine($"AFTER Swap: a = {a}, b = {b}");

            Console.WriteLine("\nResetting values...");
            Console.WriteLine("Enter value for a: ");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value for b: ");
            b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\nSwapping using a third variable...");
            Console.WriteLine($"BEFORE Swap: a = {a}, b = {b}");
            int temp = a;
            a = b;
            b = temp;
            Console.WriteLine($"AFTER Swap: a = {a}, b = {b}");
            Console.ReadKey();
        }
    }
}