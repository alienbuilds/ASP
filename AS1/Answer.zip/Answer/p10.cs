﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Answer
{
    internal class p10
    {
        public void ArrayOfFloats()
        {
            float[] numbers = new float[10]; 

            Console.WriteLine("Enter 10 floating-point numbers:");

            for (int i = 0; i < 10; i++)
            {
                Console.Write("Enter number " + (i + 1) + ": ");
                numbers[i] = Convert.ToSingle(Console.ReadLine());
            }

            Console.WriteLine("\n:");
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(numbers[i]);
            }
        }
    }
}
