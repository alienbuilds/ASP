﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Answer
{
    internal class p11
    {

        public void SmallLestLargestInFloatArray()
        {
            float[] numbers = new float[10]; 

            Console.WriteLine("Enter 10 floating-point numbers:");

            for (int i = 0; i < 10; i++)
            {
                Console.Write("Enter number " + (i + 1) + ": ");
                numbers[i] = Convert.ToSingle(Console.ReadLine());
            }

            float largest = numbers[0];
            float smallest = numbers[0];

            for (int i = 1; i < 10; i++)
            {
                if (numbers[i] > largest)
                {
                    largest = numbers[i];
                }

                if (numbers[i] < smallest)
                {
                    smallest = numbers[i];
                }
            }

            Console.WriteLine("\nThe largest number is: " + largest);
            Console.WriteLine("The smallest number is: " + smallest);
        }
    }

    }


