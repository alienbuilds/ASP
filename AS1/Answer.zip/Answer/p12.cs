﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Answer
{
    internal class p12
    {
        public void SumAndAvgOfArray()
        {
            int[] numbers = new int[8];
            int sum = 0;

            Console.WriteLine("Enter 8 Numbers :");

            for (int i = 0; i < 8; i++)
            {
                Console.Write("Enter number " + (i + 1) + ": ");
                numbers[i] = Convert.ToInt32(Console.ReadLine());
                sum += numbers[i];
            }

            double average = sum / 8;

            Console.WriteLine("\nSum of the array elements: " + sum);
            Console.WriteLine("Average of the array elements: " + average);
        }
    }
}
