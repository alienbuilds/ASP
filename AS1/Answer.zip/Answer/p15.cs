﻿using System;

namespace Answer
{
    internal class p15
    {
        public void Palindrome()
        {
            Console.Write("Enter a string: ");
            string input = Console.ReadLine();

            int length = input.Length;  

            char[] reversed = new char[length];
            int j = 0;

            for (int i = length - 1; i >= 0; i--)
            {
                reversed[j] = input[i];
                j++;
            }

            bool isPalindrome = true;
            for (int i = 0; i < length; i++)
            {
                if (input[i] != reversed[i])
                {
                    isPalindrome = false;
                    break;
                }
            }

            if (isPalindrome)
                Console.WriteLine("The string is a palindrome.");
            else
                Console.WriteLine("The string is not a palindrome.");
        }
    }
}
