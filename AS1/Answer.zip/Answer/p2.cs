﻿using System;


namespace Answer
{
    internal class p2
    {
        public void ConvertKms()
        {
            Console.WriteLine("Enter distance in kilometers: ");
            double kilometers = Convert.ToDouble(Console.ReadLine());

            double meters = kilometers * 1000;
            double feet = kilometers * 3280.84;
            double inches = kilometers * 39370.1;
            double centimeters = kilometers * 100000;

            Console.WriteLine($"Meters: {meters}");
            Console.WriteLine($"Feet: {feet}");
            Console.WriteLine($"Inches: {inches}");
            Console.WriteLine($"Centimeters: {centimeters}");
        }
    }
}
