﻿using System;

namespace Answer
{
    internal class p3
    {
        public void Arithmatic()
        {
            double A, B;
            Console.WriteLine("Enter the first number: ");
            A = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter the second number: ");
            B = Convert.ToDouble(Console.ReadLine());

            char operatorSymbol;

            do
            {
                Console.WriteLine("Enter an operator (+, -, *, /) or 'x' to exit: ");
                operatorSymbol = Convert.ToChar(Console.ReadLine());

                switch (operatorSymbol)
                {
                    case '+':
                        Console.WriteLine("Result: " + (A + B));
                        break;
                    case '-':
                        Console.WriteLine("Result: " + (A - B));
                        break;
                    case '*':
                        Console.WriteLine("Result: " + (A * B));
                        break;
                    case '/':
                        if (B != 0)
                            Console.WriteLine("Result: " + (A / B));
                        else
                            Console.WriteLine("Division by zero is not allowed.");
                        break;
                    case 'x':
                        Console.WriteLine("Exiting the program.");
                        break;
                    default:
                        Console.WriteLine("Invalid operator.");
                        break;
                }
            } while (operatorSymbol != 'x');
        }

    }
}

