﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Answer
{
    internal class p5
    {
        public void ReverseNumber()
        {
            Console.WriteLine("Enter a number (two or more digits): ");
            int number = Convert.ToInt32(Console.ReadLine());

            int reversedNumber = 0;

            while (number != 0)
            {
                int digit = number % 10;
                reversedNumber = reversedNumber * 10 + digit;
                number /= 10;
            }

            Console.WriteLine("Reversed number: " + reversedNumber);
        }
    }
}
