﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Answer
{
    internal class p6
    {
        public void CheckNumber()
        {
            Console.WriteLine("Enter a number: ");
            int number = Convert.ToInt32(Console.ReadLine());

            if (number % 5 == 0 && number % 7 == 0 && number % 11 != 0)
            {
                Console.WriteLine("The number is a multiple of 5, divisible by 7, but not divisible by 11.");
            }
            else
            {
                Console.WriteLine("The number does not meet the criteria.");
            }
        }
    }
}
