﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Answer
{
    internal class p8
    {
        public void Sum()
        {
            Console.WriteLine("Enter the first number: ");
            int start = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the second number: ");
            int end = Convert.ToInt32(Console.ReadLine());

            if (start > end)
            {
                int temp = start;
                start = end;
                end = temp;
            }

            int sum = 0;

            for (int i = start; i <= end; i++)
            {
                if (i % 2 == 0)
                {
                    sum = sum+i;  
                }
            }

            Console.WriteLine("The sum of even numbers between " + start + " and " + end + " is: " + sum);
        }
    }
}
