﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Answer
{
    internal class p9
    {
        public void Fibonacci()
        {
            int a = 0, b = 1;

            Console.WriteLine("Fibonacci series up to 300:");

            Console.Write(a + " ");
            Console.Write(b + " ");

            while (true)
            {
                int nextTerm = a + b;
                if (nextTerm > 300)
                {
                    break;
                }

                Console.Write(nextTerm + " ");
                a = b;
                b = nextTerm;
            }
        }
    }
}

